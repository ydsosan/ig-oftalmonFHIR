# hl7.fhir.cl.oftalmologia#0.1.0: null(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [](Patient-PatientExample.ai.md)
* [](Patient-PatientExample.change.history.md)
* [](Patient-PatientExample.md)
* [](Patient-PatientExample.json.md)
* [](Patient-PatientExample.ttl.md)
* [](Patient-PatientExample.xml.md)
* [](StructureDefinition-MyPatient-definitions.md)
* [](StructureDefinition-MyPatient-examples.md)
* [](StructureDefinition-MyPatient-mappings.md)
* [](StructureDefinition-MyPatient-testing.md)
* [](StructureDefinition-MyPatient.ai.md)
* [](StructureDefinition-MyPatient.md)
* [](StructureDefinition-MyPatient.profile.history.md)
* [](StructureDefinition-MyPatient.profile.json.md)
* [](StructureDefinition-MyPatient.profile.ttl.md)
* [](StructureDefinition-MyPatient.profile.xml.md)

## Resources

### ValueSets

* [Lateralidad](ValueSet-lateralidad-vs.md)

### Resource Profiles

* [Paciente Oftalmológico](StructureDefinition-Paciente-PacienteOftalmologia.md)
* [Dispositivo Oftalmológico](StructureDefinition-dispositivo-oftalmologico.md)
* [Encuentro Clínico Oftalmológico](StructureDefinition-encuentro-oftalmologia.md)
* [Procedimiento Oftalmológico](StructureDefinition-procedimiento-oftalmologia.md)

### Extensions

* [Lateralidad](StructureDefinition-lateralidad.md)

### ImplementationGuides

* [OftalmonFHIR](ImplementationGuide-hl7.fhir.cl.oftalmologia.md)

### Examples

* [LenteIntraocularEjemplo (Device)](Device-LenteIntraocularEjemplo.md)
* [EncuentroEjemplo (Encounter)](Encounter-EncuentroEjemplo.md)
* [PacienteEjemplo (Patient)](Patient-PacienteEjemplo.md)
* [ProcedimientoEjemploCatarata (Procedure)](Procedure-ProcedimientoEjemploCatarata.md)
